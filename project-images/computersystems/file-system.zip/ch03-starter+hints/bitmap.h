// based on cs3650 starter code

#ifndef BITMAP_H
#define BITMAP_H

int bitmap_get(int* bm, int ii);
int* bitmap_put(int* bm, int ii, int vv);
int* bitmap_print(int* bm);

#endif
